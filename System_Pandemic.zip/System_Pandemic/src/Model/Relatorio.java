package Model;

import java.util.List;

public interface Relatorio {
	
	public double criarRelatorio(List<Hospital> hospitais);
	
	
}
