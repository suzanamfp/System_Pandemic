package Model;

import java.util.List;

public class Hospital {
	
	public String nome;
	public String endereco;
	public String cnpj;
	public List<ListaRecursos> ListaRecursos;
	public double percentualOcupacao; 
	public int tempoDeOcupacao;
	
	public Hospital(String nome, String endereco, String cnpj, List<ListaRecursos> listaRecursos, double percentualOcupacao, int tempoDeOcupacao ) {
		super();
		this.nome = nome;
		this.endereco = endereco;
		this.cnpj = cnpj;
		this.ListaRecursos = listaRecursos;
		this.percentualOcupacao = percentualOcupacao;
		this.tempoDeOcupacao = tempoDeOcupacao;
	}
	

	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getEndereco() {
		return endereco;
	}
	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}
	public String getCnpj() {
		return cnpj;
	}
	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}
	public List<ListaRecursos> getListaRecursos() {
		return ListaRecursos;
	}
	public void setListaHospitais(List<ListaRecursos> listaHospitais) {
		ListaRecursos = listaHospitais;
	}

	public double getPercentualOcupacao() {
		return percentualOcupacao;
	}

	public void setPercentualOcupacao(double percentualOcupacao) {
		this.percentualOcupacao = percentualOcupacao;
	}
	
	public int getTempoDeOcupacao() {
		return tempoDeOcupacao;
	}


	public void setTempoDeOcupacao(int tempoDeOcupacao) {
		this.tempoDeOcupacao = tempoDeOcupacao;
	}
	
	
	
	
	
	
	
	

}
