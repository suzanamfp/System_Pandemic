package Model;

import java.util.List;

public class SuperLotacao implements Relatorio {

	//15 dias = tempo m�dio de ocupa��o
	
	@Override
	public double criarRelatorio(List<Hospital> hospitais) {
			int count = 0;
		
		for (Hospital hospital : hospitais) {
			if (hospital.getPercentualOcupacao() > 90 && hospital.getTempoDeOcupacao() > 15) {
				count = count +1;
				System.out.println("Hospital em super-lota��o: " + hospital.getNome());
			}else {
				System.out.println(" ");
			}
	
		}
		
		return (count);
}	
	

}
