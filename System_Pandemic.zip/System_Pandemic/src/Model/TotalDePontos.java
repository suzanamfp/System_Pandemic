package Model;

public class TotalDePontos{

	public PontosPorRecurso estrategia;
	
	public TotalDePontos(PontosPorRecurso pontosProRecurso) {
		this.estrategia = pontosProRecurso;
	}

	public int calculaTotalDePontos(int quantRecurso, int pontos, int quantRecurso2, int pontos2 ) {
		return estrategia.operacao1(quantRecurso, pontos) + estrategia.operacao2(quantRecurso2, pontos2);
	}
		
	
}
