package Model;

import java.util.List;

public class ListaHospitais {
	
	private List<Hospital> listaHospitais;
	
	

	public ListaHospitais(List<Hospital> listaHospitais) {
		this.listaHospitais = listaHospitais;
	}

	
	public List<Hospital> getListaHospitais() {
		return listaHospitais;
	}

	public void setListaHospitais(List<Hospital> listaHospitais) {
		this.listaHospitais = listaHospitais;
	}
	
	
	
}
