package Model;

import java.util.List;

public class RecursoPorHospital implements Relatorio {

	
	@Override
	public double criarRelatorio(List<Hospital> hospitais) {
			
		int count = 0;
		
		for (Hospital hospital : hospitais) {
			System.out.println("Hospital: " + hospital.getNome() + "\nLista de recusrsos" + hospital.getListaRecursos());
		
			count = count + 1 ;
		}
		
		return (count);
	}	
	

}

