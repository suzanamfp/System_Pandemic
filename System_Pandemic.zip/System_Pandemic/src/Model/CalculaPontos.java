package Model;

public interface CalculaPontos {
	
		public int operacao1(int quantRecurso, int pontos);
		public int operacao2(int quantRecurso2, int pontos2);

}
