package Model;

import java.util.ArrayList;
import java.util.List;


public class CriadorDeHospitais {
	
	public String nomeDoHospital;
	public String endereco;
	public String cnpj;
	public List<ListaRecursos> ListRec = new ArrayList<ListaRecursos>();
	public double percentualOcupacao;
	public int tempoDeOcupacao;
	

	public void inserirNome(String nomeDoHospital) {
		this.nomeDoHospital = nomeDoHospital;
	}
	
	public void inserirEndereco(String endereco) {
		this.endereco = endereco;
	}
	
	public void inserirCnpj(String cnpj) {
		this.cnpj = cnpj;
	}
	
	public void listarRecursos(ListaRecursos hospital) {
		ListRec.add(hospital);
	}
	
	public void inserirPercentualOcupacao(double percentualOcupacao) {
		this.percentualOcupacao = percentualOcupacao;
	}
	
	public void inserirTempoDeOcupacao(int tempoDeOcupacao) {
		this.tempoDeOcupacao = tempoDeOcupacao;
	}
	
	public Hospital criarHospital() {
		return new Hospital(nomeDoHospital, endereco, cnpj, ListRec, percentualOcupacao, tempoDeOcupacao);
	}
	
}
