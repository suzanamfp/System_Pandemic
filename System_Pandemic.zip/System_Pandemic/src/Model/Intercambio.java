package Model;

public class Intercambio {
	
	public Hospital hospital;
	
	
	public Intercambio(Hospital hospital) {
		super();
		this.hospital = hospital;
	}

	public boolean validarIntercambio() {
		if (hospital.getPercentualOcupacao() > 90) {
			System.out.println("Pode trocar recurso");
			return true;
		}else {
			System.out.println("N�o pode trocar recurso");
		}
		return false ;
	}

}
