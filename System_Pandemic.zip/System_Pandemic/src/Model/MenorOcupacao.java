package Model;

import java.util.List;

public class MenorOcupacao implements Relatorio{
	
	
	
	@Override
	public double criarRelatorio(List<Hospital> hospitais)  {
		int count = 0;
		
		for (Hospital hospital : hospitais) {
			if (hospital.getPercentualOcupacao() < 90) {
				count = count +1;
			}else {
				System.out.println(" ");
			}
	
		}
		
		return (count*100/hospitais.size());
}	

}
