package Model;

public class ListaRecursos {
	
	public int quantRecursos;
	public String recursos;

	
	
	public ListaRecursos(int quantRecursos, String recursos) {
		super();
		this.quantRecursos = quantRecursos;
		this.recursos = recursos;
		
		
	}


	public String getRecursos() {
		return recursos;
	}


	public void setRecursos(String recursos) {
		this.recursos = recursos;
	}


	public int getQuantRecursos() {
		return quantRecursos;
	}


	public void setQuantRecursos(int quantRecursos) {
		this.quantRecursos = quantRecursos;
	}


	@Override
	public String toString() {
		return "ListaRecursos [quantRecursos=" + getQuantRecursos() + ", recursos=" + getRecursos() + "]";
	}


	
	
	
	
	
	

}
