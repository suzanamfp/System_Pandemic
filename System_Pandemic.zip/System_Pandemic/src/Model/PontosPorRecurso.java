package Model;

public class PontosPorRecurso implements CalculaPontos {

	@Override
	public int operacao1(int quantRecurso, int pontos) {
		return (quantRecurso*pontos);
	}
	
	@Override
	public int operacao2(int quantRecurso2, int pontos2) {
		return (quantRecurso2*pontos2);
	}

	

}
