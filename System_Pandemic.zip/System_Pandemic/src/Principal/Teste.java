package Principal;

import java.util.ArrayList;
import java.util.List;

import Model.BaixaLotacao;
import Model.CriadorDeHospitais;
import Model.Hospital;
import Model.Intercambio;
import Model.ListaHospitais;
import Model.ListaRecursos;
import Model.MaiorOcupacao;
import Model.MenorOcupacao;
import Model.PontosPorRecurso;
import Model.RecursoPorHospital;
import Model.Relatorio;
import Model.SuperLotacao;
import Model.TotalDePontos;


public class Teste {
	
	public static void main(String[] args) {
		
		// ----Hospital 1--------
		
		CriadorDeHospitais builder1 =  new CriadorDeHospitais();
		builder1.inserirNome("Unimed");
		builder1.inserirEndereco("Rua das flores");
		builder1.inserirCnpj("333.333.333/001-33");
		builder1.listarRecursos(new ListaRecursos(2, "respirador"));
		builder1.listarRecursos(new ListaRecursos(1, "Enfermeiro"));
		builder1.inserirPercentualOcupacao(91.0);
		builder1.inserirTempoDeOcupacao(30);
		
		
		Hospital hospital1 = builder1.criarHospital();
		System.out.println("[Relat�rio]" + "\nHospital: " + hospital1.getNome() +
				", " + "\nEndere�o: " + hospital1.getEndereco() + 
				", " + "\nCNPJ: " + hospital1.getCnpj() + 
				", " + "\nQuantidade e Recursos: " + hospital1.getListaRecursos().get(0).toString() +
				", " + "\nQuantidade e Recursos: " + hospital1.getListaRecursos().get(1).toString() +
				"," + "\nPercentual de ocupa��o: " +hospital1.getPercentualOcupacao() +
				"," + "\nTempo de ocupa��o: " +hospital1.getTempoDeOcupacao() + "meses");
		
		// ----Hospital 2--------
		
		System.out.println("   ");
		
		CriadorDeHospitais builder2 =  new CriadorDeHospitais();
		builder2.inserirNome("Hapvida");
		builder2.inserirEndereco("Rua das Rosas");
		builder2.inserirCnpj("444.444.444/001-44");
		builder2.listarRecursos(new ListaRecursos(1, "M�dico"));
		builder2.listarRecursos(new ListaRecursos(1, "Ambul�ncia"));
		builder2.inserirPercentualOcupacao(88.0);
		builder2.inserirTempoDeOcupacao(10);
		
		Hospital hospital2 = builder2.criarHospital();
		System.out.println("[Relat�rio]" + "\nHospital: " + hospital2.getNome() +
				", " + "\nEndere�o: " + hospital2.getEndereco() + 
				", " + "\nCNPJ: " + hospital2.getCnpj() + 
				", " + "\nRecursos e Ocupa��o: " + hospital2.getListaRecursos().get(0).toString() +
				", " + "\nRecursos e Ocupa��o: " + hospital2.getListaRecursos().get(1).toString() +
				", " + "\nPercentual de ocupa��o: " + hospital2.getPercentualOcupacao() +
				"," + "\nTempo de ocupa��o: " +hospital2.getTempoDeOcupacao() + "meses");
		
		System.out.println("   ");
		
		System.out.println("----------PONTUA��O INTERC�MBIO-----------------------");
		
		// PONTUA��O UNIMED
		
		TotalDePontos totalDePontos = new TotalDePontos(new PontosPorRecurso());
		System.out.println("Pontua��o final da Unimed: " + totalDePontos.calculaTotalDePontos(2, 5, 1, 3));
		
		System.out.println("   ");
		
		// PONTUA��O HAPVIDA
		
		TotalDePontos totalDePontos3 = new TotalDePontos(new PontosPorRecurso());
		System.out.println("Pontua��o final da Hapvida: " + totalDePontos3.calculaTotalDePontos(2, 5, 1, 3));
		
		
		System.out.println("   ");
		
		Intercambio intercambio = new Intercambio(hospital1);
		intercambio.validarIntercambio();
		
		
		System.out.println("   ");
		
		System.out.println("--------------RELAT�RIOS-----------------------");
		
		List<Hospital> ListaHospitais = new ArrayList<Hospital>();
		ListaHospitais.add(hospital1);
		ListaHospitais.add(hospital2);
		
		//MaiorOcupacao maiorOcupacao = new MaiorOcupacao();
		//System.out.println("Percentual de hospitais com mais de 90% de ocupa��o: "+ maiorOcupacao.criarRelatorio(ListaHospitais) + "%");
		
		System.out.println("   ");
		
		MenorOcupacao menorOcupacao = new MenorOcupacao();
		System.out.println("Percentual de hospitais com menos de 90% de ocupa��o: " + menorOcupacao.criarRelatorio(ListaHospitais) + "%");
		
		System.out.println("   ");
		
		SuperLotacao superLotacao = new SuperLotacao();
		System.out.println("Quantidade de hospitais com maior super-lota��o: " + superLotacao.criarRelatorio(ListaHospitais));
		
		System.out.println("   ");
		
		BaixaLotacao baixaLotacao = new BaixaLotacao();
		System.out.println("Quantidade de hospitais com menor lota��o: " + baixaLotacao.criarRelatorio(ListaHospitais));
		
		System.out.println("   ");
		
		RecursoPorHospital RecursoPorHospital = new RecursoPorHospital();
		System.out.println("Quantidade de hospitais: " + RecursoPorHospital.criarRelatorio(ListaHospitais));
		
	}
	
	
	
	
		 
		
	
	

}
